/**
 * File navigation.js.
 *
 * adapts classes to bootstrap
 * 
 */
(function( $ ) {
    $( 'li.menu-item-has-children a' ).removeClass().addClass( 'dropdown-toggle' ).attr("data-toggle", "dropdown");
})( jQuery );
